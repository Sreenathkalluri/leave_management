function checkLeave() {
    let name = document.getElementById("userName").value;
    
    fetch(`/leave-balance/${name}`)
        .then(res => res.text()) // Expect text response
        .then(data => {
            document.getElementById("balanceResult").innerHTML = data; // Use innerHTML to render formatted text
        })
        .catch(() => document.getElementById("balanceResult").innerText = "❌ Error fetching data");
}

function applyLeave() {
    let name = document.getElementById("leaveUser").value;
    let leaveType = document.getElementById("leaveType").value;
    let days = document.getElementById("leaveDays").value;

    fetch("/apply-leave", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, leave_type: leaveType, days })
    })
    .then(res => res.text())
    .then(data => document.getElementById("applyResult").innerHTML = data) // Use innerHTML to keep formatting
    .catch(() => document.getElementById("applyResult").innerText = "❌ Error applying leave");
}
